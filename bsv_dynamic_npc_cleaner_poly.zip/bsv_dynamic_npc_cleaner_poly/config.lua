Config = {}

Config.UseAcePermission = true
Config.AcePermission = 'npczone.admin'
Config.AdminGroups = { 'god', 'admin', 'mod' }

Config.CheckInterval = 2000
Config.Debug = false

Config.RemovePeds = true
Config.RemoveNpcVehicles = true
Config.RemoveAmbientVehicles = false

Config.IgnorePlayers = true
Config.IgnoreMissionEntities = true

Config.RemoveMode = 'delete'
Config.DisableDensityInsideZone = true

Config.DefaultRadius = 100.0
Config.MinRadius = 10.0
Config.MaxRadius = 3000.0

Config.Creator = {
    minPoints = 3,
    pointMarkerScale = 0.45
}

Config.Commands = {
    createCircle = 'npczone',
    createPoly = 'npczonepoly',
    remove = 'removenpczone',
    list = 'listnpczones',
    toggle = 'togglenpczone',
    clear = 'clearnpczones',
    reload = 'reloadnpczones',
    show = 'shownpczones'
}

Config.Keys = {
    addPoint = 38,
    finish = 191,
    cancel = 194
}

Config.ShowZonesDefault = false

Config.Marker = {
    circle = { r = 255, g = 0, b = 0, a = 80 },
    poly = { r = 0, g = 180, b = 255, a = 220 },
    point = { r = 255, g = 255, b = 0, a = 220 }
}
