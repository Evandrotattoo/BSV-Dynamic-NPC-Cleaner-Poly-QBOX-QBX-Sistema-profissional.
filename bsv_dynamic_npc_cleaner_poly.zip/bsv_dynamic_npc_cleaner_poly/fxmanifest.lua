fx_version 'cerulean'
game 'gta5'

author 'BSV Solutions'
description 'Dynamic NPC Cleaner com zonas circulares e desenhadas por pontos'
version '2.0.0'

lua54 'yes'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

files {
    'zones.json'
}
