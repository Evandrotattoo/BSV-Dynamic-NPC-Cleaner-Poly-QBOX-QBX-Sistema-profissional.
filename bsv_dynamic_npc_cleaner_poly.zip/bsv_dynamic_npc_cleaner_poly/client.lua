local zones = {}
local showZones = Config.ShowZonesDefault
local creatingPoly = false
local polyPoints = {}

local function toVec3(t)
    return vec3(t.x, t.y, t.z)
end

local function chat(msg)
    TriggerEvent('chat:addMessage', { args = { 'NPC Zone', msg } })
end

RegisterNetEvent('bsv_dynamic_npc_cleaner:client:setZones', function(serverZones)
    zones = serverZones or {}
end)

CreateThread(function()
    Wait(2000)
    TriggerServerEvent('bsv_dynamic_npc_cleaner:server:requestZones')
end)

RegisterNetEvent('bsv_dynamic_npc_cleaner:client:createCircleFromCoords', function(radius)
    local coords = GetEntityCoords(PlayerPedId())
    TriggerServerEvent('bsv_dynamic_npc_cleaner:server:addCircleZone', { x = coords.x, y = coords.y, z = coords.z }, radius)
end)

local function pointInPoly(point, poly)
    local inside = false
    local j = #poly

    for i = 1, #poly do
        local pi = poly[i]
        local pj = poly[j]

        if ((pi.y > point.y) ~= (pj.y > point.y)) and
            (point.x < (pj.x - pi.x) * (point.y - pi.y) / ((pj.y - pi.y) + 0.00001) + pi.x) then
            inside = not inside
        end

        j = i
    end

    return inside
end

local function isInsideZone(coords)
    for _, zone in ipairs(zones or {}) do
        if zone.enabled then
            if zone.type == 'circle' then
                if #(coords - toVec3(zone.coords)) <= zone.radius then
                    return true, zone
                end
            elseif zone.type == 'poly' and zone.points then
                if pointInPoly(coords, zone.points) then
                    return true, zone
                end
            end
        end
    end

    return false, nil
end

local function removeEntity(entity)
    if Config.RemoveMode == 'despawn' then
        SetEntityAsNoLongerNeeded(entity)
        return
    end

    SetEntityAsMissionEntity(entity, true, true)
    DeleteEntity(entity)
end

local function canRemovePed(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if Config.IgnorePlayers and IsPedAPlayer(ped) then return false end
    if Config.IgnoreMissionEntities and IsEntityAMissionEntity(ped) then return false end
    return true
end

CreateThread(function()
    while true do
        Wait(Config.CheckInterval or 2000)

        if Config.RemovePeds then
            for _, ped in ipairs(GetGamePool('CPed')) do
                if canRemovePed(ped) and isInsideZone(GetEntityCoords(ped)) then
                    removeEntity(ped)
                end
            end
        end

        if Config.RemoveNpcVehicles or Config.RemoveAmbientVehicles then
            for _, veh in ipairs(GetGamePool('CVehicle')) do
                if DoesEntityExist(veh) and isInsideZone(GetEntityCoords(veh)) then
                    local hasPlayer = false

                    for seat = -1, GetVehicleMaxNumberOfPassengers(veh) - 1 do
                        local ped = GetPedInVehicleSeat(veh, seat)
                        if ped and ped ~= 0 and IsPedAPlayer(ped) then
                            hasPlayer = true
                            break
                        end
                    end

                    if not hasPlayer then
                        local driver = GetPedInVehicleSeat(veh, -1)

                        if Config.RemoveAmbientVehicles and (not driver or driver == 0) then
                            removeEntity(veh)
                        elseif Config.RemoveNpcVehicles and driver and driver ~= 0 and not IsPedAPlayer(driver) then
                            removeEntity(veh)
                        end
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        if Config.DisableDensityInsideZone then
            local coords = GetEntityCoords(PlayerPedId())

            if isInsideZone(coords) then
                SetPedDensityMultiplierThisFrame(0.0)
                SetScenarioPedDensityMultiplierThisFrame(0.0, 0.0)
                SetRandomVehicleDensityMultiplierThisFrame(0.0)
                SetParkedVehicleDensityMultiplierThisFrame(0.0)
                SetVehicleDensityMultiplierThisFrame(0.0)
                Wait(0)
            else
                Wait(500)
            end
        else
            Wait(1000)
        end
    end
end)

RegisterNetEvent('bsv_dynamic_npc_cleaner:client:startPolyCreator', function()
    creatingPoly = true
    polyPoints = {}

    chat('Modo desenho iniciado.')
    chat('E = marcar ponto | ENTER = salvar | BACKSPACE = cancelar')
end)

CreateThread(function()
    while true do
        local sleep = 1000

        if creatingPoly then
            sleep = 0
            local coords = GetEntityCoords(PlayerPedId())

            DrawMarker(1, coords.x, coords.y, coords.z - 1.0, 0,0,0, 0,0,0, 1.2,1.2,0.2, 255,255,0,160, false,false,2,false,nil,nil,false)

            if IsControlJustPressed(0, Config.Keys.addPoint) then
                polyPoints[#polyPoints + 1] = { x = coords.x, y = coords.y, z = coords.z }
                chat(('Ponto %s marcado.'):format(#polyPoints))
            end

            if IsControlJustPressed(0, Config.Keys.finish) then
                if #polyPoints >= Config.Creator.minPoints then
                    TriggerServerEvent('bsv_dynamic_npc_cleaner:server:addPolyZone', polyPoints)
                    creatingPoly = false
                    polyPoints = {}
                    chat('Zona desenhada salva.')
                else
                    chat('Você precisa de pelo menos 3 pontos.')
                end
            end

            if IsControlJustPressed(0, Config.Keys.cancel) then
                creatingPoly = false
                polyPoints = {}
                chat('Criação cancelada.')
            end

            for i, point in ipairs(polyPoints) do
                DrawMarker(28, point.x, point.y, point.z + 0.2, 0,0,0, 0,0,0, Config.Creator.pointMarkerScale, Config.Creator.pointMarkerScale, Config.Creator.pointMarkerScale, 255,255,0,220, false,false,2,false,nil,nil,false)

                local nextPoint = polyPoints[i + 1]
                if nextPoint then
                    DrawLine(point.x, point.y, point.z + 0.2, nextPoint.x, nextPoint.y, nextPoint.z + 0.2, 255, 255, 0, 220)
                end
            end

            if #polyPoints >= 1 then
                local last = polyPoints[#polyPoints]
                DrawLine(last.x, last.y, last.z + 0.2, coords.x, coords.y, coords.z + 0.2, 0, 255, 255, 180)
            end
        end

        Wait(sleep)
    end
end)

RegisterCommand(Config.Commands.show, function()
    showZones = not showZones
    chat('Mostrar zonas: ' .. tostring(showZones))
end)

CreateThread(function()
    while true do
        local sleep = 1000

        if showZones then
            sleep = 0

            for _, zone in ipairs(zones or {}) do
                if zone.enabled then
                    if zone.type == 'circle' then
                        local coords = toVec3(zone.coords)
                        local c = Config.Marker.circle
                        DrawMarker(1, coords.x, coords.y, coords.z - 1.0, 0,0,0, 0,0,0, zone.radius * 2.0, zone.radius * 2.0, 1.0, c.r,c.g,c.b,c.a, false,false,2,false,nil,nil,false)
                    elseif zone.type == 'poly' and zone.points then
                        local c = Config.Marker.poly

                        for i, point in ipairs(zone.points) do
                            local nextPoint = zone.points[i + 1] or zone.points[1]
                            DrawLine(point.x, point.y, point.z + 0.3, nextPoint.x, nextPoint.y, nextPoint.z + 0.3, c.r,c.g,c.b,220)
                            DrawMarker(28, point.x, point.y, point.z + 0.2, 0,0,0, 0,0,0, 0.35,0.35,0.35, c.r,c.g,c.b,220, false,false,2,false,nil,nil,false)
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end)
