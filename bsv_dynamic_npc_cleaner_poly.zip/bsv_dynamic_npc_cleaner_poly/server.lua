local zones = {}
local zonesFile = 'zones.json'

local function hasPermission(src)
    if src == 0 then return true end
    if not Config.UseAcePermission then return true end

    if Config.AcePermission and Config.AcePermission ~= '' then
        if IsPlayerAceAllowed(src, Config.AcePermission) then
            return true
        end
    end

    local groups = Config.AdminGroups or { 'god', 'admin', 'mod' }
    for i = 1, #groups do
        local group = groups[i]
        if group and group ~= '' then
            if IsPlayerAceAllowed(src, ('group.%s'):format(group)) or IsPlayerAceAllowed(src, group) then
                return true
            end
        end
    end

    if GetResourceState('qbx_core') == 'started' then
        local ok, allowed = pcall(function()
            return exports.qbx_core:HasPermission(src, groups)
                or exports.qbx_core:HasPermission(src, Config.AcePermission or 'admin')
        end)

        if ok and allowed then
            return true
        end
    end

    return false
end

local function loadZones()
    local content = LoadResourceFile(GetCurrentResourceName(), zonesFile)
    if content and content ~= '' then
        local decoded = json.decode(content)
        if decoded then zones = decoded end
    end
end

local function saveZones()
    SaveResourceFile(GetCurrentResourceName(), zonesFile, json.encode(zones, { indent = true }), -1)
end

local function sync(target)
    TriggerClientEvent('bsv_dynamic_npc_cleaner:client:setZones', target or -1, zones)
end

CreateThread(function()
    loadZones()
    Wait(1000)
    sync(-1)
    print(('[BSV NPC CLEANER] %s zonas carregadas.'):format(#zones))
end)

AddEventHandler('playerJoining', function()
    local src = source
    Wait(3000)
    sync(src)
end)

RegisterNetEvent('bsv_dynamic_npc_cleaner:server:requestZones', function()
    sync(source)
end)

RegisterCommand(Config.Commands.createCircle, function(source, args)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Sem permissão.' } })
        return
    end

    local radius = tonumber(args[1]) or Config.DefaultRadius
    radius = math.max(Config.MinRadius, math.min(Config.MaxRadius, radius))

    TriggerClientEvent('bsv_dynamic_npc_cleaner:client:createCircleFromCoords', source, radius)
end)

RegisterCommand(Config.Commands.createPoly, function(source)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Sem permissão.' } })
        return
    end

    TriggerClientEvent('bsv_dynamic_npc_cleaner:client:startPolyCreator', source)
end)

RegisterNetEvent('bsv_dynamic_npc_cleaner:server:addCircleZone', function(coords, radius)
    local src = source
    if not hasPermission(src) then return end

    local id = os.time() .. '_' .. math.random(1000, 9999)

    zones[#zones + 1] = {
        id = id,
        type = 'circle',
        name = ('Circle %s'):format(#zones + 1),
        coords = coords,
        radius = radius,
        enabled = true
    }

    saveZones()
    sync(-1)

    TriggerClientEvent('chat:addMessage', src, {
        args = { 'NPC Zone', ('Zona circular criada. ID: %s | Raio: %sm'):format(id, radius) }
    })
end)

RegisterNetEvent('bsv_dynamic_npc_cleaner:server:addPolyZone', function(points)
    local src = source
    if not hasPermission(src) then return end

    if type(points) ~= 'table' or #points < Config.Creator.minPoints then
        TriggerClientEvent('chat:addMessage', src, { args = { 'NPC Zone', 'Zona precisa de pelo menos 3 pontos.' } })
        return
    end

    local id = os.time() .. '_' .. math.random(1000, 9999)

    zones[#zones + 1] = {
        id = id,
        type = 'poly',
        name = ('Poly %s'):format(#zones + 1),
        points = points,
        enabled = true
    }

    saveZones()
    sync(-1)

    TriggerClientEvent('chat:addMessage', src, {
        args = { 'NPC Zone', ('Zona desenhada criada. ID: %s | Pontos: %s'):format(id, #points) }
    })
end)

RegisterCommand(Config.Commands.remove, function(source, args)
    if not hasPermission(source) then return end

    local id = args[1]
    if not id then
        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Use: /removenpczone ID' } })
        return
    end

    for i, zone in ipairs(zones) do
        if tostring(zone.id) == tostring(id) then
            table.remove(zones, i)
            saveZones()
            sync(-1)
            TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Zona removida: ' .. id } })
            return
        end
    end

    TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Zona não encontrada.' } })
end)

RegisterCommand(Config.Commands.toggle, function(source, args)
    if not hasPermission(source) then return end

    local id = args[1]
    if not id then
        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Use: /togglenpczone ID' } })
        return
    end

    for _, zone in ipairs(zones) do
        if tostring(zone.id) == tostring(id) then
            zone.enabled = not zone.enabled
            saveZones()
            sync(-1)
            TriggerClientEvent('chat:addMessage', source, {
                args = { 'NPC Zone', ('Zona %s: %s'):format(id, zone.enabled and 'ATIVA' or 'OFF') }
            })
            return
        end
    end
end)

RegisterCommand(Config.Commands.list, function(source)
    if not hasPermission(source) then return end

    if #zones == 0 then
        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Nenhuma zona criada.' } })
        return
    end

    for _, zone in ipairs(zones) do
        local info = zone.type == 'poly'
            and ('ID: %s | POLY | Pontos: %s | %s'):format(zone.id, #(zone.points or {}), zone.enabled and 'ATIVA' or 'OFF')
            or ('ID: %s | CIRCLE | Raio: %sm | %s'):format(zone.id, zone.radius, zone.enabled and 'ATIVA' or 'OFF')

        TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', info } })
    end
end)

RegisterCommand(Config.Commands.clear, function(source)
    if not hasPermission(source) then return end

    zones = {}
    saveZones()
    sync(-1)

    TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Todas as zonas foram removidas.' } })
end)

RegisterCommand(Config.Commands.reload, function(source)
    if not hasPermission(source) then return end

    loadZones()
    sync(-1)

    TriggerClientEvent('chat:addMessage', source, { args = { 'NPC Zone', 'Zonas recarregadas.' } })
end)
