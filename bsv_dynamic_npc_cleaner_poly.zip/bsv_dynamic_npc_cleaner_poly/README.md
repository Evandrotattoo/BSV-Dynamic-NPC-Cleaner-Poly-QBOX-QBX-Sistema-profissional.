# BSV Dynamic NPC Cleaner Poly

Script independente para remover NPCs em zonas criadas por comando.

## Instalação

```cfg
ensure bsv_dynamic_npc_cleaner_poly
add_ace group.admin npczone.admin allow
```

## Criar zona circular

```txt
/npczone 300
```

## Criar zona desenhada por pontos

```txt
/npczonepoly
```

Controles:

```txt
E = marcar ponto
ENTER = salvar área
BACKSPACE = cancelar
```

## Outros comandos

```txt
/listnpczones
/removenpczone ID
/togglenpczone ID
/shownpczones
/clearnpczones
/reloadnpczones
```

## O que remove

- NPCs pedestres dentro da área
- veículos dirigidos por NPC dentro da área
- densidade local dentro da área

## O que não remove

- players
- veículos com players dentro
- NPCs fora da área
- restante da cidade
